package com.example.headshottraining;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.view.View;
import android.view.MotionEvent;
import android.widget.*;
import android.graphics.Typeface;
import android.content.Context;
import android.view.Gravity;

public class MainActivity extends Activity {
    private PracticeView practice;
    private TextView status;
    private boolean running = false;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(24, 24, 24, 24);
        page.setBackgroundColor(Color.rgb(16, 20, 30));

        TextView title = new TextView(this);
        title.setText("HEADSHOT TRAINING");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, 56));

        TextView note = new TextView(this);
        note.setText("Practice-only touch trainer • does not control Free Fire");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        page.addView(note);

        practice = new PracticeView(this);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, 0, 1);
        vp.setMargins(0, 18, 0, 18);
        page.addView(practice, vp);

        addSlider(page, "Pull speed", 1, 10, 5, v -> practice.speed = v);
        addSlider(page, "Pull strength", 1, 10, 5, v -> practice.strength = v);

        Button start = new Button(this);
        start.setText("START PRACTICE");
        start.setOnClickListener(v -> {
            running = true;
            practice.active = true;
            status.setText("Practice active — drag upward toward the target");
            practice.invalidate();
        });
        page.addView(start);

        Button stop = new Button(this);
        stop.setText("STOP / RESET");
        stop.setOnClickListener(v -> {
            running = false;
            practice.active = false;
            practice.reset();
            status.setText("Stopped — ready when you are");
        });
        page.addView(stop);

        status = new TextView(this);
        status.setText("Stopped — ready when you are");
        status.setTextColor(Color.WHITE);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 12, 0, 0);
        page.addView(status);

        setContentView(page);
    }

    interface SliderChange { void change(int value); }

    private void addSlider(LinearLayout parent, String label, int min, int max, int initial, SliderChange cb) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setPadding(0, 10, 0, 0);
        parent.addView(t);
        SeekBar s = new SeekBar(this);
        s.setMax(max - min);
        s.setProgress(initial - min);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) { cb.change(p + min); }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        parent.addView(s);
    }

    class PracticeView extends View {
        Paint p = new Paint(3);
        float targetX, targetY;
        float fingerX, fingerY;
        boolean dragging = false;
        boolean active = false;
        int speed = 5, strength = 5;
        int hits = 0;

        PracticeView(Context c) { super(c); setBackgroundColor(Color.rgb(29, 37, 53)); }
        void reset() { hits = 0; dragging = false; invalidate(); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float cx = getWidth()/2f, cy = getHeight()/2f;
            targetX = cx;
            targetY = getHeight()*0.28f;
            p.setColor(Color.WHITE); p.setTextSize(32); p.setTextAlign(Paint.Align.CENTER);
            c.drawText("DRAG UP TO THE TARGET", cx, 48, p);
            p.setColor(Color.rgb(230, 65, 75)); c.drawCircle(targetX, targetY, 34, p);
            p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4);
            c.drawCircle(targetX, targetY, 44, p); p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(90, 190, 255)); c.drawCircle(cx, getHeight()*0.82f, 28, p);
            if (dragging) {
                p.setColor(Color.YELLOW); p.setStrokeWidth(5);
                c.drawLine(fingerX, fingerY, cx, getHeight()*0.82f, p);
            }
            p.setColor(Color.WHITE); p.setTextSize(20);
            c.drawText("Hits: " + hits, cx, getHeight()-22, p);
            if (!active) {
                p.setTextSize(18); p.setColor(Color.LTGRAY);
                c.drawText("Press START to begin", cx, cy, p);
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (!active) return true;
            float x = e.getX(), y = e.getY();
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                dragging = true; fingerX = x; fingerY = y; invalidate(); return true;
            } else if (e.getAction() == MotionEvent.ACTION_MOVE && dragging) {
                fingerX = x; fingerY = y; invalidate(); return true;
            } else if (e.getAction() == MotionEvent.ACTION_UP && dragging) {
                float dx = Math.abs(x - getWidth()/2f);
                float dy = Math.abs(y - getHeight()*0.28f);
                if (dx < (22 + strength*2) && dy < (25 + speed*2)) hits++;
                dragging = false; invalidate(); return true;
            }
            return true;
        }
    }
}
