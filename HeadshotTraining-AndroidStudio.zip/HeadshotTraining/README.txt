HEADSHOT TRAINING — Android Studio project

This is a practice-only touch trainer. It does not overlay, automate, read,
or control Free Fire or any other game.

Build:
1. Open Android Studio.
2. Choose Open and select the HeadshotTraining folder.
3. Let Gradle sync.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.

Requires Android Studio with Android Gradle Plugin 8.6.1 support.
